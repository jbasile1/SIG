package org.geotools.tutorial.quickstart;

public class Livreur
{
	
	private double longitude,latitude;
	private Thread_Livreur threadlivreur;
	
	
	public Livreur ()
	{
	//	threadlivreur =new Thread_Livreur();
		
	}

}
