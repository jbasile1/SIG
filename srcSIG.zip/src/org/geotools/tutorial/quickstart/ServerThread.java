package org.geotools.tutorial.quickstart;

public class ServerThread extends Thread
{
	private Serveur serv;

	public ServerThread(Serveur serv)
	{
		super();
		this.serv = serv;
	}
	
	@Override
	public void run()
	{
		super.run();
	}
}
